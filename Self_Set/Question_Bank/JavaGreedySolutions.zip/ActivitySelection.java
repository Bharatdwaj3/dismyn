import java.util.*;

public class ActivitySelection {
    public static int maxActivities(int[][] intervals) {
        Arrays.sort(intervals, Comparator.comparingInt(a -> a[1]));
        int count = 0, end = -1;
        for (int[] i : intervals) {
            if (i[0] > end) {
                count++;
                end = i[1];
            }
        }
        return count;
    }

    public static void main(String[] args) {
        int[][] intervals = {{1, 3}, {2, 4}, {3, 5}};
        System.out.println(maxActivities(intervals));
    }
}